/*
The Learn Programming Academy
Java SE 11 Developer 1Z0-819 OCP Course - Part 2
Section 9: Migration to Modular System.
*/
package sample.core;

public class UtilityClass {
    public static void doSomethingStatic(String s) {
        System.out.println(s);
    }
}